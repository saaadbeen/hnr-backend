package com.example.HNR.DTO;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PVDTO {
    private Long pvId;
    private String contenu;
    private Date dateRedaction;
    private String numero;
    private boolean valide;
    private String urlPDF;
    private Long actionId;
    private String redacteurUserId;
    private String validateurUserId;
    private Date dateValidation;
    private Date createdAt;
}