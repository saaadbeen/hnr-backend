package com.example.HNR.DTO;

import com.example.HNR.Model.SqlServer.PV;
import com.example.HNR.Model.SqlServer.Action;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PvResponse {
    private Action action;
    private PV pv;
}
