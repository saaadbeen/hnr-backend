package com.example.HNR.DTO;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MissionDTO {
    private Long missionId;
    private Date dateEnvoi;
    private String prefecture;
    private String commune;
    private String rapportPDF;
    private String statut;
    private String createdByUserId;
    private List<String> assignedUserIds;
    private int nombreDouars;
    private int nombreActions;
    private Date createdAt;
    private Date completedAt;
}