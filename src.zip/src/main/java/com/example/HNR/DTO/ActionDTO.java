package com.example.HNR.DTO;

import com.example.HNR.Model.enums.TypeAction;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ActionDTO {
    private Long actionId;
    private Date dateAction;
    private TypeAction type;
    private String prefecture;
    private String commune;
    private String userId;
    private Long douarId;
    private String douarNom;
    private Long missionId;
    private boolean hasPV;
    private Date createdAt;
}