package com.example.HNR.DTO;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FichierDTO {
    private Long fichierId;
    private String fileName;
    private String url;
    private String contentType;
    private Long size;
    private String entityType;
    private Long entityId;
    private String uploadedByUserId;
    private Date uploadedAt;
    private boolean isImage;
    private boolean isPDF;
    private String formattedSize;
}