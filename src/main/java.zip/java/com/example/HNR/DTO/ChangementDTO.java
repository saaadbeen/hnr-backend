package com.example.HNR.DTO;

import com.example.HNR.Model.enums.TypeExtension;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChangementDTO {
    private Long changementId;
    private TypeExtension type;
    private Date dateBefore;
    private Date dateAfter;
    private Double surface;
    private String photoBefore;
    private String photoAfter;
    private Long douarId;
    private String douarNom;
    private String detectedByUserId;
    private boolean hasPhotos;
    private Date createdAt;
}