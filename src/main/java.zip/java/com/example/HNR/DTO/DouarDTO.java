package com.example.HNR.DTO;

import com.example.HNR.Model.enums.StatutDouar;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DouarDTO {
    private Long douarId;
    private String nom;
    private StatutDouar statut;
    private String prefecture;
    private String commune;
    private String createdByUserId;
    private Double latitude;
    private Double longitude;
    private int nombreActions;
    private int nombreChangements;
    private Date createdAt;
    private Date updatedAt;
}